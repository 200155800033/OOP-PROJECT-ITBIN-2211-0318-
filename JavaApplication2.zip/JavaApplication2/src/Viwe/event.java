/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Viwe;

import Model.DBconnct;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author ferna
 */
public class event extends javax.swing.JFrame {

      Connection conn = null;
    PreparedStatement pst = null;
   
    public event() {
        initComponents();
         conn = DBconnct.connect();
       tableload();
    }

      public void tabledata(){
    
        int r = t2.getSelectedRow();
        
        String id =t2.getValueAt(r, 0).toString();
        String name = t2.getValueAt(r, 1).toString();
        String typ=t2.getValueAt(r, 2).toString();
         String add=t2.getValueAt(r, 3).toString();
          String num=t2.getValueAt(r, 4).toString();
          
          
          
        jTextField1.setText(id);
        jTextField2.setText(name);
        jComboBox1.setSelectedItem(typ);
        jTextField3.setText(add);
        jTextField4.setText(num);
   }
       ResultSet rs;
      
      
      public void tableload(){
        try {
            
          String sql ="SELECT EVENTID,ORGANIZERNAME,DANCETYPE,LOCATION,ORGANIZERNUMBER FROM eventdetailes ";
          pst = conn.prepareStatement(sql);
          rs = pst.executeQuery();
          t2.setModel(DbUtils.resultSetToTableModel(rs));
          
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
}
}
      
public void update() {
    String id = jTextField1.getText();
    String name = jTextField2.getText();
    String typ = jComboBox1.getSelectedItem().toString();
    String add = jTextField3.getText();
    String num = jTextField4.getText();
    
    try {
        String sql = "UPDATE eventdetailes SET ORGANIZERNAME=?, DANCETYPE=?, LOCATION=?,ORGANIZERNUMBER =? WHERE EVENTID =?";
        pst = conn.prepareStatement(sql);
        pst.setString(1, name);
        pst.setString(2, typ);
        pst.setString(3, add);
        pst.setString(4, num);
        pst.setString(5, id);
        pst.executeUpdate();
        JOptionPane.showMessageDialog(null, "Update");
    } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(null, "Updatefaile:"+e.getMessage());
    }finally {
        try {
            if(pst!=null)pst.close();
        } catch (Exception e) {
        }
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        upb = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        t2 = new javax.swing.JTable();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        subb = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        deb = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        upb.setBackground(new java.awt.Color(153, 255, 255));
        upb.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("EVENT ID :");
        upb.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 100, 30));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("ORGANIZER NAME :");
        upb.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 160, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("DANCE TYPE :");
        upb.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 157, 120, 30));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("EVENT LOCATION :");
        upb.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("ORGANIZER PHONE NUMBER :");
        upb.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, -1, -1));

        t2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        t2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                t2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(t2);

        upb.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 320, 440, 100));
        upb.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 90, 280, -1));
        upb.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 130, 280, -1));
        upb.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 200, 280, -1));
        upb.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 240, 280, -1));

        jComboBox1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "TRADETIONAL", "WESTERN", "MIX" }));
        upb.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 170, -1, -1));

        jPanel2.setBackground(new java.awt.Color(0, 0, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 255, 0));
        jLabel1.setText("Event Dtailes..");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 0, 310, 50));

        upb.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, -1));

        jPanel1.setBackground(new java.awt.Color(0, 0, 255));

        subb.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        subb.setText("SUBMIT");
        subb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subbActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("UPDATE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        deb.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        deb.setText("DELETE");
        deb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                debActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setText("GOTO HOME");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(subb)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(51, 51, 51)
                .addComponent(deb)
                .addGap(49, 49, 49)
                .addComponent(jButton2)
                .addGap(53, 53, 53))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(subb)
                    .addComponent(jButton1)
                    .addComponent(deb)
                    .addComponent(jButton2))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        upb.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 480, 650, 60));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Photos/Dance-Performance-Groups-website-card-image-2023.jpg"))); // NOI18N
        jLabel7.setText("jLabel7");
        upb.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 650, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(upb, javax.swing.GroupLayout.PREFERRED_SIZE, 652, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 2, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(upb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 4, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void subbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subbActionPerformed
            int id;
            String oname;
            String type;
            String loca;
           

    try {
        id = Integer.parseInt(jTextField1.getText());
        oname = jTextField2.getText();
        type = jComboBox1.getSelectedItem().toString();
        loca =jTextField3.getText();
         int onumber = Integer.parseInt(jTextField4.getText());

        String sql = "INSERT INTO eventdetailes(EVENTID,ORGANIZERNAME,DANCETYPE,LOCATION,ORGANIZERNUMBER) VALUES (?, ?, ?, ?, ?)";
           PreparedStatement pst= conn.prepareStatement(sql);

        pst.setInt(1, id);
        pst.setString(2, oname);
        pst.setString(3, type);
        pst.setString(4, loca);
        pst.setInt(5, onumber);

        pst.executeUpdate();
        
        JOptionPane.showMessageDialog(null, "Record inserted successfully");

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Invalid input format: " + e.getMessage());
    } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
}
     
    tableload();
                                         

    }//GEN-LAST:event_subbActionPerformed

    private void t2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_t2MouseClicked
       tabledata();
    }//GEN-LAST:event_t2MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       update();
       tableload();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void debActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_debActionPerformed
             int check = JOptionPane.showConfirmDialog(null, "Do you want to delete?");
         
         if (check == 0){
             String id = jTextField1.getText();
             try {
                 String sql = "DELETE FROM eventdetailes WHERE EVENTID=?";
                 pst = conn.prepareStatement(sql);
                 pst.setString(1, id);
                 pst.executeUpdate();
                 JOptionPane.showMessageDialog(null, "Deleted");
             } catch (Exception e) {
                 JOptionPane.showMessageDialog(null, "Deletefailed:"+ e.getMessage());
             }finally{
                 try {
                     if(pst!=null)pst.close();
                 } catch (SQLException e) {
                     e.printStackTrace();
                 }
             }
         }
         tableload();
    }//GEN-LAST:event_debActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      login chamu = new login();
      chamu.setVisible(true);
      this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(event.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(event.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(event.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(event.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new event().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton deb;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JButton subb;
    private javax.swing.JTable t2;
    private javax.swing.JPanel upb;
    // End of variables declaration//GEN-END:variables

   
}
