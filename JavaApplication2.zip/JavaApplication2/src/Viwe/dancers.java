/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Viwe;

import Model.DBconnct;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import net.proteanit.sql.DbUtils;





public final class dancers extends javax.swing.JFrame {

     Connection conn = null;
    PreparedStatement pst = null;
   
    
   
    public dancers() {
        initComponents();
          
        conn = DBconnct.connect();
        tableload();
        
         
        
    }
    

   public void tabledata(){
    
        int r = jTable1.getSelectedRow();
        
        String id =jTable1.getValueAt(r, 0).toString();
        String name = jTable1.getValueAt(r, 1).toString();
        String typ=jTable1.getValueAt(r, 2).toString();
         String add=jTable1.getValueAt(r, 3).toString();
          String num=jTable1.getValueAt(r, 4).toString();
          
          
          
        jTextField1.setText(id);
        jTextField2.setText(name);
        jComboBox1.setSelectedItem(typ);
        jTextField3.setText(add);
        jTextField4.setText(num);
   }
   ResultSet rs;
public void tableload(){
        try {
            
          String sql ="SELECT dancerid,name,gender,address,phoneno FROM  dancers";
          pst = conn.prepareStatement(sql);
          rs = pst.executeQuery();
          jTable1.setModel(DbUtils.resultSetToTableModel(rs));
          
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
}
}



public void update() {
    String id = jTextField1.getText();
    String name = jTextField2.getText();
    String typ = jComboBox1.getSelectedItem().toString();
    String add = jTextField3.getText();
    String num = jTextField4.getText();
    
    try {
        String sql = "UPDATE dancers SET name=?, gender=?, address=?, phoneno=? WHERE dancerid=?";
        pst = conn.prepareStatement(sql);
        pst.setString(1, name);
        pst.setString(2, typ);
        pst.setString(3, add);
        pst.setString(4, num);
        pst.setString(5, id);
        pst.executeUpdate();
        JOptionPane.showMessageDialog(null, "Update");
    } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(null, "Updatefaile:"+e.getMessage());
    }finally {
        try {
            if(pst!=null)pst.close();
        } catch (Exception e) {
        }
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        nextbtn = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();

        jPanel5.setBackground(new java.awt.Color(51, 0, 204));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("DANCER ID :");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 80, -1));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 130, 220, -1));

        jLabel3.setText("DANCER NAME :");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 100, -1));
        jPanel1.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, 220, -1));

        jLabel4.setText("GENDER :");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 70, -1));

        jComboBox1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MALE", "FEMALE" }));
        jPanel1.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 230, 90, -1));

        jLabel5.setText("ADDRESS :");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 80, -1));
        jPanel1.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 270, 220, -1));

        jLabel6.setText("PHONE NUMBER :");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 110, -1));
        jPanel1.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 220, -1));

        jButton1.setText("SUBMIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 400, -1, 30));

        jButton2.setText("Update");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 460, -1, 30));

        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 400, 90, 30));

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("DANCERS DETAILS FROM");
        jPanel2.add(jLabel1);

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 60));

        nextbtn.setText("NEXT");
        nextbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextbtnActionPerformed(evt);
            }
        });
        jPanel1.add(nextbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 460, 80, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 400, 550));
        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 310, -1, -1));

        jPanel8.setBackground(new java.awt.Color(0, 255, 255));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel8.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 100));

        getContentPane().add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 420, 460, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Photos/Website-CaroseulCurrent-Families-Photos-800-x-600-px-3.jpg"))); // NOI18N
        jLabel7.setText("jLabel7");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, -10, -1, 740));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       int type;
    String name;
    String gender;
    String address;
    int mobileNumber;

    try {
        type = Integer.parseInt(jTextField1.getText());
        name = jTextField2.getText();
        gender = jComboBox1.getSelectedItem().toString();
        address = jTextField3.getText();
        mobileNumber = Integer.parseInt(jTextField4.getText());

        String sql = "INSERT INTO dancers(dancerid, name, gender, address, phoneno) VALUES (?, ?, ?, ?, ?)";
           PreparedStatement pst= conn.prepareStatement(sql);

        pst.setInt(1, type);
        pst.setString(2, name);
        pst.setString(3, gender);
        pst.setString(4, address);
        pst.setInt(5, mobileNumber);

        pst.executeUpdate();
        
        JOptionPane.showMessageDialog(null, "Record inserted successfully");

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Invalid input format: " + e.getMessage());
    } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
}
tableload();
    
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
 tabledata();        
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        update();
        tableload();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int check = JOptionPane.showConfirmDialog(null, "Do you want to delete?");
         
         if (check == 0){
             String id = jTextField1.getText();
             try {
                 String sql = "DELETE FROM dancers WHERE dancerid=?";
                 pst = conn.prepareStatement(sql);
                 pst.setString(1, id);
                 pst.executeUpdate();
                 JOptionPane.showMessageDialog(null, "Deleted");
             } catch (Exception e) {
                 JOptionPane.showMessageDialog(null, "Deletefailed:"+ e.getMessage());
             }finally{
                 try {
                     if(pst!=null)pst.close();
                 } catch (SQLException e) {
                     e.printStackTrace();
                 }
             }
         }
         tableload();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void nextbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextbtnActionPerformed
     event teranaiya = new event();
   teranaiya.setVisible(true);
    this.dispose();
     
    }//GEN-LAST:event_nextbtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(dancers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(dancers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(dancers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(dancers.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new dancers().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JButton nextbtn;
    // End of variables declaration//GEN-END:variables
}
